#ifndef GPIO_H_
#define GPIO_H_

//TI Includes
#include <Headers/F2837xD_device.h>

void gpio_init();


#endif /* GPIO_H_ */
